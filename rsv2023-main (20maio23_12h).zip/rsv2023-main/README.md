## LINKS PARA ACESSO: 
- [Protótipo RSV23](https://lacelabcct-rsv2023-main-gfq3kv.streamlit.app)
- [Portal da Transparência](https://portaldatransparencia.gov.br/localidades)
