from setuptools import setup

with open("README.md", "r") as fh:
    readme = fh.read()

setup(
    name='laceRSV23_v1',
    version='0.0.1',
    url='https://github.com/lacelabcct/rsv2023.git',
    license='MIT License',
    author='Pedro Henrique Trindade e Elisabete Olimpio',
    long_description=readme,
    long_description_content_type="text/markdown",
    author_email='lace.lab.cct@gmail.com',
    keywords='Pacote',
    description='Pacote PyPI',
    packages=['laceRSV23_v1'],
    install_requires=['pandas',
                      'streamlit',
                      'requests',
                      'beautifulsoup4',
                      'streamlit-chat',
                      'matplotlib'],
)